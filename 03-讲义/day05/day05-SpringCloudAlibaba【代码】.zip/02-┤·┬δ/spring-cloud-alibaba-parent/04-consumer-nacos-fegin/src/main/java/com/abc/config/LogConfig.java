package com.abc.config;

import org.springframework.context.annotation.Configuration;

/**
 * feign客户端配置类
 * 配置日志输出级别
 */
@Configuration
public class LogConfig {
}
